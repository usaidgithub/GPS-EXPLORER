window.onload = function() {
    var map = L.map('map',{
        center: [39.0, -93.3],
        zoom: 8,
        maxZoom: 18,
        minZoom: 4,
    });
    
    
    
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);
    var osmb = new OSMBuildings(map);
    osmb.load('https://{s}.data.osmbuildings.org/0.2/anonymous/tile/{z}/{x}/{y}.json');
    var userMarker
        // Initialize rotation angle
        
    
    function searchLocation() {
      var searchText = document.getElementById("searchInput").value;
      if (searchText) {
        fetch(`https://api.opencagedata.com/geocode/v1/json?q=${searchText}&key=5b9c82a1a5f8485794424f746851f6c4`)
          .then(response => response.json())
          .then(data => {
            if (data.results.length > 0) {
              var lat = data.results[0].geometry.lat;
              var lon = data.results[0].geometry.lng;
              map.setView([lat, lon], 13);
              var searchMarker = L.marker([lat, lon]).addTo(map);
              searchMarker.bindPopup(searchText).openPopup();
            } else {
              alert("Location not found!");
            }
          })
          .catch(error => console.log(error));
      } else {
        alert("Please enter a location!");
      }
    }
    document.getElementById("searchbutton").addEventListener("click",searchLocation) 
    function addUserMarker(lat, lon) {
      var userMarker = L.marker([lat, lon]).addTo(map);
      userMarker.bindPopup("Your Location").openPopup();
      map.setView([lat, lon], 13);
    }
    function getUserLocation() {
      if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
              var lat = position.coords.latitude;
              var lon = position.coords.longitude;
              addUserMarker(lat, lon);
          }, function(error) {
              console.log(error);
              alert("Error getting your location: " + error.message);
          });
      } else {
          alert("Geolocation is not supported by your browser.");
      }
    }
    getUserLocation();
    // Call getUserLocation function when the page loads
    function trackShortestDistance() {
      var destination = document.getElementById("searchInput").value;
      if (destination) {
        if ("geolocation" in navigator) {
          navigator.geolocation.getCurrentPosition(function (position) {
            var lat = position.coords.latitude;
            var lon = position.coords.longitude;
            if (userMarker) {
              map.removeLayer(userMarker);
            }
            userMarker = L.marker([lat, lon]).addTo(map);
            userMarker.bindPopup("Your Location").openPopup();
            fetch(`https://api.opencagedata.com/geocode/v1/json?q=${destination}&key=5b9c82a1a5f8485794424f746851f6c4`)
              .then(response => response.json())
              .then(data => {
                if (data.results.length > 0) {
                  var destLat = data.results[0].geometry.lat;
                  var destLon = data.results[0].geometry.lng;
                  L.Routing.control({
                    waypoints: [
                      L.latLng(lat, lon),
                      L.latLng(destLat, destLon)
                    ]
                  }).addTo(map);
                } else {
                  alert("Destination not found!");
                }
              })
              .catch(error => console.log(error));
          });
        }
      } else {
        alert("Please enter a destination!");
      }
    }
    document.getElementById("track").addEventListener("click",trackShortestDistance) 
    
    // L.geoJson(vt_layer).addTo(map);
    var highlight;
            var clearHighlight = function() {
                if (highlight) {
                    vectorGrid.resetFeatureStyle(highlight);
                }
                highlight = null;
            };
    var vectorGrid = L.vectorGrid.slicer(vt_layer, {
      rendererFactory: L.svg.tile,
      vectorTileLayerStyles: {
        sliced: function(properties, zoom) {
          var p = properties.D01;
          return {
            fillColor: p <= 10 ? '#800026' :
                        p <= 20 ? '#BD0026' :
                        p <= 30 ? '#E31A1C' :
                        p <= 40 ? '#FC4E2A' :
                        p <= 50 ? '#FD8D3C' :
                        p <= 60 ? '#FEB24C' :
                        p <= 70 ? '#FED976' :
                        p <= 80 ? '#FFEDA0' :
                        '#FFFFFF',
            fillOpacity: 0.5,
             //fillOpacity: 1,
            stroke: true,
            fill: true,
            color: 'black',
               //opacity: 0.2,
            weight: 0,
          }
        }
      },
      interactive: true,
      getFeatureId: function(f) {
        return f.properties.D01;
      }
    })
    .on('mouseover', function(e) {
      var properties = e.layer.properties;
      L.popup()
        .setContent(properties.NAMELSAD10 + ': ' + properties.D01 + '%')
        .setLatLng(e.latlng)
        .openOn(map);
    
      clearHighlight();
      highlight = properties.D01;
    
      var p = properties.D01;
      var style = {
        fillColor: p <= 10 ? '#800026' :
                        p <= 20 ? '#BD0026' :
                        p <= 30 ? '#E31A1C' :
                        p <= 40 ? '#FC4E2A' :
                        p <= 50 ? '#FD8D3C' :
                        p <= 60 ? '#FEB24C' :
                        p <= 70 ? '#FED976' :
                        p <= 80 ? '#FFEDA0' :
                        '#FFFFFF',
        fillOpacity: 0.5,
        fillOpacity: 1,
        stroke: true,
        fill: true,
        color: 'red',
        opacity: 1,
        weight: 2,
      };
    
      vectorGrid.setFeatureStyle(properties.D01, style);
    }).addTo(map);
    
    //add rotation on click
    
    //on click check button remove the vt_layer
    document.getElementById("remove").onclick = function() {
      map.removeLayer(vectorGrid);
    };
      
    
    build= L.easyButton('fa-home fa-lg', function(){
      osmb = new OSMBuildings(map).load('https://{s}.data.osmbuildings.org/0.2/anonymous/tile/{z}/{x}/{y}.json'); 
    },"Show 2.5D Buildings",'topleft').addTo(map);
    
    
    }