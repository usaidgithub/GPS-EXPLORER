const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true // Ensures uniqueness of usernames
  },
  password: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true // Ensures uniqueness of email addresses
  },
});

const User = mongoose.model('User', userSchema); // Defining the User model

module.exports = User; // Exporting the User model