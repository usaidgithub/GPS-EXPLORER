const express = require('express');
const mongoose = require('mongoose');
const path=require('path');
const UserModel = require('./User'); // Import the file containing the User model

const app = express();
app.use(express.static(path.join(__dirname,'..')));
app.use(express.json());
app.use(express.urlencoded({extended:true}));

mongoose.connect('mongodb://localhost:27017/Authentication', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Register endpoint to handle POST requests for user registration
app.post('/register', async (req, res) => {
  try {
    console.log('Received data:', req.body); // Add this line to log the received data

    const { username, password, email } = req.body;

    // Ensure username and password are present
    if (!username || !password) {
      return res.status(400).send('Username and password are required');
    }

    // Create a new user instance based on the User model
    const newUser = new UserModel({ username, password, email });

    // Save the new user to the database
    await newUser.save();

    res.redirect('/test.html')
  } catch (err) {
    console.error(err);
    res.status(500).send('Error registering user');
  }
});

// Login endpoint to handle POST requests for user login
app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = await UserModel.findOne({ username });

    if (!user) {
      return res.status(401).send('Invalid username or password');
    }

    // Compare the entered password with the stored password in the database (plaintext)
    if (password !== user.password) {
      return res.status(401).send('Invalid username or password');
    }

    res.redirect('/login.html');
  }
   catch (err) {
    console.error(err);
    res.status(500).send('Error during login');
  }
});
app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname,'..','login.html'));
});
app.get('/test.html', (req, res) => {
  res.sendFile(path.join(__dirname,'..','test.html'));
}); 
const PORT = process.env.PORT || 3000; // Use the environment port or 3000 as a default
app.listen(PORT, () => {
  console.log("Server is running on port", PORT);
});